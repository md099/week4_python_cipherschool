import pdb
pdb.set_trace()
name = input("Enter your name: ")
age = input("Enter your age: ")
print(f"hello {name} your age is {age}") 
age2 = age+5
print(f"hello {name} your age will be {age} in next five years") 
